#ifndef _JVNSDKDEF_H_H
#define _JVNSDKDEF_H_H
#define MOBILE_CLIENT 1


void writeLog(char* format, ...);

void deleteLog();



#endif

