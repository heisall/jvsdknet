#ifndef JVNERROR_H
#define JVNERROR_H

/********************************************************************
�豸�˺ͷֿض˲������ͳһ����
*********************************************************************/
#define JVN_OK                 0//�ɹ�
#define JVN_CONN_                 1//
#define JVN_CONN_                 2//
#define JVN_CONN_                 3//
#define JVN_CONN_                 4//
#define JVN_                 5//
#define JVN_                 6//
#define JVN_                 7//
#define JVN_                 8//
#define JVN_                 9//
#define JVN_                 10//
#define JVN_                 11//
#define JVN_                 12//
#define JVN_                 13//
#define JVN_                 14//
#define JVN_                 15//
#define JVN_                 16//
#define JVN_                 17//
#define JVN_                 18//
#define JVN_                 19//
#define JVN_                 20//
#define JVN_                 21//
#define JVN_                 22//
#define JVN_                 23//
#define JVN_                 24//
#define JVN_                 25//
#define JVN_                 26//
#define JVN_                 27//
#define JVN_                 28//
#define JVN_                 29//
#define JVN_                 30//

#endif